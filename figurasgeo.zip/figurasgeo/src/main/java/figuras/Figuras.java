package figuras;

public abstract class Figuras 
{
    public abstract double calcularArea();
    public abstract double calcularPerimetro();
}
